package com.cnit355.converter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener{
    Spinner spinner;
    String[] Temp={"C","F","K"};
    EditText editText;
    TextView cText,fText,kText;
    ImageButton buttonLength, buttonScale, buttonTemp, buttonHelp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        spinner= (Spinner)findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);

        cText=(TextView)findViewById(R.id.ctextView);
        fText=(TextView)findViewById(R.id.ftextView);
        kText=(TextView)findViewById(R.id.ktextView);

        buttonHelp=(ImageButton) findViewById(R.id.imageButtonhelp) ;
        buttonLength=(ImageButton) findViewById(R.id.imageButtonlength);
        buttonScale=(ImageButton) findViewById(R.id.imageButtonscale) ;
        buttonTemp=(ImageButton) findViewById(R.id.imageButtontemp) ;
        editText=(EditText)findViewById(R.id.editText);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, Temp);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(adapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        convertTemp(i);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
    public void MoveToScale(View view){
        Intent mIntent= new Intent(this, SecondActivity.class);
        startActivity(mIntent);
    }

    public void MoveToLength(View view) {
        Intent mIntent = new Intent(this, MainActivity.class);
        startActivity(mIntent);
    }

    public void MoveToHelp(View view){
        Intent mIntent = new Intent(this, FourthActivity.class);
        startActivity(mIntent);

    }

    public void convertTemp(int a){
        double input;
        String in;
        double c = 0;
        double f = 0;
        double k = 0;

        //editText initial value set in xml
        in = editText.getText().toString();
        input = Double.parseDouble(in.trim());
        switch (a) {
            case 0:
                c = input;
                f = input * 33.8;
                k = input * 274.15;
                break;

            case 1:
                c = input * (-17.2222);
                f = input;
                k = input *255.928;
                break;

            case 2:
                c = input * (-272.15);
                f = input * (-457.87);
                k = input;
                break;
        }
        cText.setText(Double.toString(c) +" C");
        kText.setText(Double.toString(k)+" K");
        fText.setText(Double.toString(f)+ " F");
    }

}
