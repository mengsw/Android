package com.cnit355.converter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener {
    Spinner spinner;
    String[] Length={"mm","cm","m","km","inch","ft","yd","mile"};
    EditText editText;
    TextView mmText,cmText,mText,kmText,inText,ftText,ydText,mileText;
    ImageButton buttonLength, buttonScale, buttonTemp, buttonHelp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner= (Spinner)findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);

        mmText=(TextView)findViewById(R.id.mmtextView);
        cmText=(TextView)findViewById(R.id.cmtextView);
        mText=(TextView)findViewById(R.id.mtextView);
        kmText=(TextView)findViewById(R.id.kmtextView);
        inText=(TextView)findViewById(R.id.inchtextView);
        ftText=(TextView)findViewById(R.id.fttextView);
        ydText=(TextView)findViewById(R.id.ydtextView);
        mileText=(TextView)findViewById(R.id.miletextView);
        buttonHelp=(ImageButton) findViewById(R.id.imageButtonhelp) ;
        buttonLength=(ImageButton) findViewById(R.id.imageButtonlength);
        buttonScale=(ImageButton) findViewById(R.id.imageButtonscale) ;
        buttonTemp=(ImageButton) findViewById(R.id.imageButtontemp) ;
        editText=(EditText)findViewById(R.id.editText);
      /*  editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                double input =Double.parseDouble(s.toString());
                String in =editText.getText().toString();

            }

            @Override
            public void afterTextChanged(Editable editable) {
            }

        });*/


        //Double input = Double.parseDouble(editText.toString());

        // a default spinner layout
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, Length);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//place each view-item inside listview by setting adapter for ourlistview
        spinner.setAdapter(adapter);

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view,
                               int position, long id) {

        // use spinner item call method
        convertLength(position);



    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void MoveToScale(View view){
        Intent mIntent= new Intent(this, SecondActivity.class);
        startActivity(mIntent);
    }

    public void MoveToTemp(View view){
        Intent mIntent= new Intent(this, ThirdActivity.class);
        startActivity(mIntent);
    }

    public void MoveToHelp(View view){
        Intent mIntent = new Intent(this, FourthActivity.class);
        startActivity(mIntent);

    }

    public void convertLength(int a){
        double input;
       String in=editText.getText().toString();
        double mm =0.0;
        double cm=0.0;
        double m=0.0;
        double km=0.0;
        double inch=0.0;
        double ft=0.0;
        double yd=0.0;
        double mile=0.0;
        input=Double.parseDouble(in.trim());
        switch (a){
            case 0: mm=input;
                cm=input/10;
                m=input/1000;
                km=input*1e-6;
                inch=input*0.0393701;
                ft=input*0.00328084;
                yd=input*0.00109361;
                mile=input*6.2137e-7;
                break;

            case 1: mm=input*10;
                cm=input;
                m=input/100;
                km=input*1e-5;
                inch=input*0.393701;
                ft=input*0.0328084;
                yd=input*0.0109361;
                mile=input*6.2137e-6;

                break;

            case 2: mm=input*1000;
                cm=input*100;
                m=input;
                km=input*1000;
                inch=input*39.3701;
                ft=input*3.28084;
                yd=input*1.09361;
                mile=input*0.000621371;

                break;

            case 3: mm=input*1e+6;
                cm=input*100000;
                m=input*1000;
                km=input;
                inch=input*39370.1;
                ft=input*3280.84;
                yd=input*1093.61;
                mile=input*0.621371;
                break;

            case 4: mm=input*25.4;
                cm=input*2.54;
                m=input*0.0254;
                km=input*2.54e-5;
                inch=input;
                ft=input*0.0833333;
                yd=input*0.0277778;
                mile=input*1.5783e-5;

                break;

            case 5: mm=input*304.8;
                cm=input*30.48;
                m=input*0.3048;
                km=input*0.0003048;
                inch=input*12;
                ft=input;
                yd=input*0.333333;
                mile=input*0.000189394;
                break;

            case 6: mm=input*914.4;
                cm=input*91.44;
                m=input*0.9144;
                km=input*0.0009144;
                inch=input*36;
                ft=input*3;
                yd=input;
                mile=input*0.000568182;

                break;


            case 7: mm=input*1.609e+6;
                cm=input*160934;
                m=input*1609.34;
                km=input*1.60934;
                inch=input*63360;
                ft=input*5280;
                yd=input*1760;
                mile=input;
                break;
        }
        mmText.setText(Double.toString(mm)+" mm");
        cmText.setText(Double.toString(cm)+" cm");
        mText.setText(Double.toString(m)+" m");
        kmText.setText(Double.toString(km)+" km");
        inText.setText(Double.toString(inch)+" inch");
        ftText.setText(Double.toString(ft)+" ft");
        ydText.setText(Double.toString(yd)+" yd");
        mileText.setText(Double.toString(mile)+" mile");


    }



}

