package com.cnit355.converter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class FourthActivity extends AppCompatActivity {
    TextView textView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth);

        textView=(TextView)findViewById(R.id.textView);
    }

    public void MoveToScale(View view){
        Intent mIntent= new Intent(this, SecondActivity.class);
        startActivity(mIntent);
    }

    public void MoveToTemp(View view){
        Intent mIntent= new Intent(this, ThirdActivity.class);
        startActivity(mIntent);
    }

    public void MoveToLength(View view)

    {
        Intent mIntent = new Intent(this, MainActivity.class);
        startActivity(mIntent);
    }
}
