package com.cnit355.converter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener{
    Spinner spinner;
    String[] Weight={"mg","g","kg","ton","oz","lb"};
    EditText editText;
    TextView mgText,gText,kgText,tonText,ozText,lbText;
    ImageButton buttonLength, buttonScale, buttonTemp, buttonHelp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        spinner= (Spinner)findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);

        mgText=(TextView)findViewById(R.id.mgtextView);
        gText=(TextView)findViewById(R.id.gtextView);
        kgText=(TextView)findViewById(R.id.kgtextView);
        tonText=(TextView)findViewById(R.id.tontextView);
        ozText=(TextView)findViewById(R.id.oztextView);
        lbText=(TextView)findViewById(R.id.lbtextView);
        buttonHelp=(ImageButton) findViewById(R.id.imageButtonhelp) ;
        buttonLength=(ImageButton) findViewById(R.id.imageButtonlength);
        buttonScale=(ImageButton) findViewById(R.id.imageButtonscale) ;
        buttonTemp=(ImageButton) findViewById(R.id.imageButtontemp) ;
        editText=(EditText)findViewById(R.id.editText);


        //Double input = Double.parseDouble(editText.toString());

        // a default spinner layout
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, Weight);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//place each view-item inside listview by setting adapter for ourlistview
        spinner.setAdapter(adapter);

    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView,
                               View view, int position, long id) {
        convertWeight(position);

    }


    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void MoveToLength(View view)

    {
        Intent mIntent = new Intent(this, MainActivity.class);
        startActivity(mIntent);
    }

    public void MoveToTemp(View view){
        Intent mIntent= new Intent(this, ThirdActivity.class);
        startActivity(mIntent);
    }

    public void MoveToHelp(View view){
        Intent mIntent = new Intent(this, FourthActivity.class);
        startActivity(mIntent);

    }

    public void convertWeight(int a){
        double input;
        String in;
        double mg = 0;
        double g = 0;
        double kg = 0;
        double ton = 0;
        double oz = 0;
        double lb = 0;
        //editText initial value set in xml
        in = editText.getText().toString();
        input = Double.parseDouble(in.trim());
        switch (a) {
            case 0:
                mg = input;
                g = input / 1000;
                kg = input * 1e-6;
                ton = input * 1.1023e-9;
                oz = input * 3.5274e-5;
                lb = input * 2.20462e-6;
                break;

            case 1:
                mg = input * 1000;
                g = input;
                kg = input / 1000;
                ton = input * 1.1023e-6;
                oz = input * 0.035274;
                lb = input * 0.00220462;
                break;

            case 2:
                mg = input * 1e+6;
                g = input * 1000;
                kg = input;
                ton = input * 0.00110231;
                oz = input * 35.274;
                lb = input * 2.20462;
                break;

            case 3:
                mg = input * 9.072e+8;
                g = input * 907185;
                kg = input * 907.185;
                ton = input;
                oz = input * 32000;
                lb = input * 2000;
                break;

            case 4:
                mg = input * 28349.5;
                g = input * 28.3495;
                kg = input * 0.0283495;
                ton = input * 3.125e-5;
                oz = input;
                lb = input * 0.0625;
                break;

            case 5:
                mg = input * 453592;
                g = input * 453.592;
                kg = input * 0.453592;
                ton = input * 0.0005;
                oz = input * 16;
                lb = input;
                break;
        }
        mgText.setText(Double.toString(mg)+ " mg");
        gText.setText(Double.toString(g)+ " g");
        kgText.setText(Double.toString(kg)+ " kg");
        tonText.setText(Double.toString(ton)+ " ton");
        ozText.setText(Double.toString(oz)+ " oz");
        lbText.setText(Double.toString(lb)+ " lb");
    }
}
